"""
story_data.py
-------------
The entire "Canvas & Conflict" story, structured as data instead of prose.

Each top-level key is a scene id (matches the ids used in the original
script: SCENE_001, SCENE_002A, etc). Each scene has:

    title                 - scene name
    background            - setting description
    time                  - in-story time
    characters_present    - who's on screen
    atmosphere            - mood/music notes
    visuals               - dict of character_name -> appearance/posture description
    dialogue              - ordered list of {"speaker": ..., "line": ...}
    choices               - ordered list of {"text": ..., "next": scene_id}
                             (omit/empty for ending scenes)
    is_ending             - True for terminal scenes
    ending_label          - short label shown on the "THE END" screen

NOTE: A few scenes (SCENE_003D, SCENE_005D) were added beyond the original
draft to close gaps where a choice pointed to a scene that was only implied,
not written out. END_A was added as an explicit ending node for the same
reason. Everything else matches the original script.
"""

STORY = {

    # ============================================================
    # ACT 1 — THE CHOICE
    # ============================================================

    "SCENE_001": {
        "title": "The Exhibition Letter",
        "background": "Modern college arts building, sunlit corridor with student artwork "
                       "lining the walls. Large windows show the green campus outside. "
                       "Bulletin boards covered with posters for an inter-college competition.",
        "time": "10:30 AM, Tuesday morning",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Uplifting, academic, possibility-filled",
        "visuals": {
            "Arjun": "Black hoodie, jeans, dark hair. Holding a golden letter, expression "
                     "caught between excitement and uncertainty.",
            "Priya": "Confident posture, photography bag across her shoulder, denim jacket "
                     "over a crop top. Walking over with assured steps.",
            "Isha": "Seated on a bench, oversized sweater, long dark hair loose. Sketching "
                    "quietly in a notebook, not yet noticing Arjun.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """(staring at the letter) "Oh my God... this is actually happening." """},
            {"speaker": "PRIYA", "line": """(arriving, looking over his shoulder) "What's happening? You look like you won the lottery." """},
            {"speaker": "ARJUN", "line": """(handing her the letter) "The Inter-College Arts Exhibition. They want me to lead a project." """},
            {"speaker": "PRIYA", "line": """(scanning it fast) "THE exhibition? With the prize pool and the magazine coverage?" """},
            {"speaker": "ARJUN", "line": """"Yeah. And they want it interdisciplinary — photography, design, and a written narrative, combined." """},
            {"speaker": "ISHA", "line": """(looking up from her notebook) "Did someone say exhibition?" """},
            {"speaker": "PRIYA", "line": """(turning to Arjun) "You have to pick me for this. My portfolio's ready." """},
            {"speaker": "ARJUN", "line": """(hesitating) "It's not just photography, Priya. I need someone for the writing too, and Isha is actually—" """},
            {"speaker": "PRIYA", "line": """(defensive) "Isha writes poetry. This needs commercial storytelling." """},
            {"speaker": "ISHA", "line": """(standing, calm) "The theme is 'Untold Stories.' Narratives that haven't been shared." """},
            {"speaker": "ARJUN", "line": """(looking between them) "I need to think. Team forms by Friday. This is huge." """},
            {"speaker": "NARRATOR", "line": "Both women are looking at him now, waiting."},
        ],
        "choices": [
            {"text": "Ask Priya to meet after college to discuss her vision.", "next": "SCENE_002A"},
            {"text": "Ask Isha for coffee to hear her thoughts on the theme.", "next": "SCENE_002B"},
            {"text": "Ask both of them to sit down together right now.", "next": "SCENE_002C"},
        ],
    },

    "SCENE_002A": {
        "title": "Priya's Ambition",
        "background": "A trendy coffee shop near campus. Exposed brick, hanging plants, "
                       "warm lighting. A corner table by the window.",
        "time": "5:30 PM, same day",
        "characters_present": "Arjun, Priya",
        "atmosphere": "Contemporary, slightly tense but engaging",
        "visuals": {
            "Priya": "Leaning forward, eyes bright, laptop open showing her portfolio.",
            "Arjun": "Sitting back, nervous coffee sips, sketchpad out, listening intently.",
        },
        "dialogue": [
            {"speaker": "PRIYA", "line": """(sliding the laptop over) "This series — 'Silent Screams.' Unspoken emotions in everyday college life." """},
            {"speaker": "ARJUN", "line": """(studying the photos) "These are incredible. How do you capture this?" """},
            {"speaker": "PRIYA", "line": """"I watch people. I understand what they're NOT saying. Combine that with your design sense and we stop people in their tracks." """},
            {"speaker": "ARJUN", "line": """"What about the written narrative the brief asks for?" """},
            {"speaker": "PRIYA", "line": """(waving it off) "Minimal captions. Visuals carry ninety-nine percent of the story." """},
            {"speaker": "ARJUN", "line": """"But the theme is 'Untold Stories'... wouldn't real writing deepen that?" """},
            {"speaker": "PRIYA", "line": """(leaning in) "We're competing against the best in the country, Arjun. We need to be bold. Isha's talented, but she's not at our level yet." """},
            {"speaker": "ARJUN", "line": """(uncomfortable) "That feels harsh." """},
            {"speaker": "PRIYA", "line": """(softer) "I'm being real. This exhibition could launch my career. I need this." """},
            {"speaker": "ARJUN", "line": """"I don't want to choose based on who needs it more. I want the best work — and real chemistry." """},
            {"speaker": "PRIYA", "line": """(coldly) "And you don't think that's us?" """},
            {"speaker": "ARJUN", "line": """"I don't know yet. That's why I'm still thinking." """},
        ],
        "choices": [
            {"text": "\"You're right. Let's do this — I'll tell Isha we're going another direction.\"", "next": "SCENE_003A"},
            {"text": "\"I need to explore the other option too before deciding. No pressure, but I have to be fair.\"", "next": "SCENE_003B"},
        ],
    },

    "SCENE_002B": {
        "title": "Isha's Depths",
        "background": "The library rooftop garden — small trees, benches, fairy lights "
                       "even in daylight. A view of the city skyline.",
        "time": "4:00 PM, same day",
        "characters_present": "Arjun, Isha",
        "atmosphere": "Contemplative, intimate, quietly mysterious",
        "visuals": {
            "Isha": "Relaxed on the bench, notebook open, completely at ease here.",
            "Arjun": "More unguarded than at the coffee shop, genuinely curious.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """(opening her notebook) "I've been writing about the exhibition theme since before the announcement. Didn't know why, at the time." """},
            {"speaker": "ARJUN", "line": """"Can I read some?" """},
            {"speaker": "ISHA", "line": """(hesitant, then nodding) "It's personal. But yeah." """},
            {"speaker": "NARRATOR", "line": "He reads. His expression shifts — genuinely moved."},
            {"speaker": "ARJUN", "line": """(softly) "These are stories nobody tells. This is real." """},
            {"speaker": "ISHA", "line": """"That's what Priya doesn't get. It's not about being marketable. It's about being honest." """},
            {"speaker": "ARJUN", "line": """"How did you know to write this before you even knew about the exhibition?" """},
            {"speaker": "ISHA", "line": """"Because these stories are always inside us. The exhibition is just an excuse to finally say them out loud." """},
            {"speaker": "ARJUN", "line": """"I think your work could be the backbone of this project. Not captions — the foundation." """},
            {"speaker": "ISHA", "line": """(surprised) "Really? Priya mentioned—" """},
            {"speaker": "ARJUN", "line": """(quickly) "Priya's amazing at what she does. But this isn't just about impressive visuals." """},
            {"speaker": "ISHA", "line": """"What's making you hesitate, then?" """},
            {"speaker": "ARJUN", "line": """"Fear of choosing wrong. Fear of letting someone down. Fear of how Priya reacts." """},
            {"speaker": "ISHA", "line": """(gently) "You can't make creative choices based on someone else's reaction." """},
            {"speaker": "ARJUN", "line": """"If I chose you, could you handle working closely with me for months?" """},
            {"speaker": "ISHA", "line": """(holding his gaze) "Yes. I think I could." """},
            {"speaker": "NARRATOR", "line": "Something passes between them — a moment of understanding."},
        ],
        "choices": [
            {"text": "\"Let's do this. I'll talk to Priya and explain.\"", "next": "SCENE_003C"},
            {"text": "\"I want to, but I need to be sure Priya's okay with it first. Give me until tomorrow?\"", "next": "SCENE_003D"},
        ],
    },

    "SCENE_002C": {
        "title": "The Three-Way Conversation",
        "background": "The college art studio. Open space, easels, natural light from "
                       "tall windows, student work on every wall. Three stools in a triangle.",
        "time": "3:30 PM, same day",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Tense, neutral, waiting for resolution",
        "visuals": {
            "Priya": "Arms loosely crossed, professional but assertive.",
            "Isha": "More open posture, notebook in her lap, slightly uncertain.",
            "Arjun": "Standing, clearly the facilitator, nervous energy.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """"I could just pick one of you right now. But that doesn't feel right — this matters, and so do both of you." """},
            {"speaker": "PRIYA", "line": """"So what are you saying?" """},
            {"speaker": "ARJUN", "line": """(sitting) "Let's talk properly. What's each of your take on 'Untold Stories'?" """},
            {"speaker": "ISHA", "line": """(softly) "The narratives that exist in silence. The emotions people don't speak." """},
            {"speaker": "PRIYA", "line": """"Capturing those stories through image. One photograph can say what takes paragraphs to write." """},
            {"speaker": "ARJUN", "line": """"Isha sees the narrative foundation, Priya sees the visual impact. What if we don't pick one — what if we blend both?" """},
            {"speaker": "PRIYA", "line": """(defensive) "Meaning Isha's poetry with my photos? That's the obvious route. Photography can work alone." """},
            {"speaker": "ISHA", "line": """(calm) "Maybe it's stronger together. If we're intentional about it." """},
            {"speaker": "PRIYA", "line": """(standing) "Adding unnecessary elements just dilutes the impact." """},
            {"speaker": "ARJUN", "line": """(matching her intensity) "Or enhances it. Makes it more human." """},
            {"speaker": "PRIYA", "line": """"This is exactly what I was afraid of — that you'd get emotionally attached and compromise the quality." """},
            {"speaker": "ISHA", "line": """(firm) "Nobody's asking you to compromise. Maybe trust that different doesn't mean worse." """},
            {"speaker": "PRIYA", "line": """(to Isha) "I don't know your work well enough to trust it. No offense." """},
            {"speaker": "ISHA", "line": """(standing too) "Then maybe we should collaborate and change that." """},
            {"speaker": "NARRATOR", "line": "Awkward silence."},
            {"speaker": "ARJUN", "line": """(breaking it) "Here's a proposal. One test piece — Priya, you shoot something based on a theme Isha writes. If it doesn't work, we go separate ways." """},
            {"speaker": "PRIYA", "line": """(reluctant) "And if it does?" """},
            {"speaker": "ARJUN", "line": """"Then we build the whole exhibition on that foundation." """},
        ],
        "choices": [
            {"text": "Priya agrees: \"Fine. But if this wastes my time, I'm done.\"", "next": "SCENE_004A"},
            {"text": "Priya refuses: \"No. I'm not compromising my vision.\"", "next": "SCENE_004B"},
        ],
    },

    "SCENE_003A": {
        "title": "The Difficult Conversation",
        "background": "A college hallway outside the art studio, late afternoon. A few "
                       "students passing by. An awkward setting for a serious talk.",
        "time": "5:00 PM, Wednesday",
        "characters_present": "Arjun, Isha",
        "atmosphere": "Melancholic, regretful, tense",
        "visuals": {
            "Arjun": "Approaching with a guilty, determined expression.",
            "Isha": "Closing her locker, not expecting what's coming.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """(awkward) "Hey Isha... can we talk?" """},
            {"speaker": "ISHA", "line": """(smiling) "Of course. What's up?" """},
            {"speaker": "ARJUN", "line": """"About the exhibition. I'm going with Priya." """},
            {"speaker": "ISHA", "line": """(smile fading) "Oh." """},
            {"speaker": "ARJUN", "line": """(defensive) "It's not that your work isn't good — it's amazing. Priya just has more commercial experience, and—" """},
            {"speaker": "ISHA", "line": """(gently) "You don't have to justify it. It's your choice." """},
            {"speaker": "ARJUN", "line": """"I'm justifying it because I feel terrible about it." """},
            {"speaker": "ISHA", "line": """(looking away) "If you feel terrible, maybe you made the wrong choice." """},
            {"speaker": "ARJUN", "line": """(quietly) "Maybe I did." """},
            {"speaker": "ISHA", "line": """(composing herself) "Good luck with the exhibition. I hope it's amazing." """},
            {"speaker": "ARJUN", "line": """"Don't do the polite thing. Tell me what you're actually feeling." """},
            {"speaker": "ISHA", "line": """(eyes watery) "Fine. I'm disappointed. I thought this was my chance to do something real. I'm hurt you chose someone else." """},
            {"speaker": "ISHA", "line": """"But more than that — I think you chose based on what Priya needed, not what the project needed. That's not fair to any of us." """},
            {"speaker": "NARRATOR", "line": "She closes her locker and starts to walk away."},
            {"speaker": "ARJUN", "line": """(calling after her) "Isha, wait—" """},
            {"speaker": "ISHA", "line": """(not turning back) "I have other stories to tell." """},
        ],
        "choices": [
            {"text": "Let her go and focus on the project with Priya.", "next": "SCENE_005A"},
            {"text": "Follow her and try to fix this.", "next": "SCENE_005B"},
        ],
    },

    "SCENE_003B": {
        "title": "The Fence",
        "background": "Campus grounds at golden hour, a walking path between buildings, "
                       "long dramatic shadows.",
        "time": "6:00 PM, Wednesday",
        "characters_present": "Arjun (alone)",
        "atmosphere": "Thoughtful, uncertain, contemplative",
        "visuals": {
            "Arjun": "Walking slowly, holding the brief, lost in thought.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """(thinking) "Priya's right about impact. Isha's right about authenticity. And I'm stuck in the middle." """},
            {"speaker": "NARRATOR", "line": "He sits, pulls out his sketchpad, and starts blending both of their styles into one sketch without meaning to."},
            {"speaker": "ARJUN", "line": """(thinking) "What if the answer isn't choosing? What if it's something neither of them expected?" """},
            {"speaker": "NARRATOR", "line": "His eyes light up. He starts scribbling notes furiously."},
        ],
        "choices": [
            {"text": "Call both of them separately to propose a new vision.", "next": "SCENE_006A"},
            {"text": "Just decide: choose Priya and stick with it.", "next": "SCENE_003A"},
            {"text": "Just decide: choose Isha and stick with it.", "next": "SCENE_003C"},
        ],
    },

    "SCENE_003C": {
        "title": "Choosing Isha",
        "background": "The rooftop garden, now at night, fairy lights glowing. Peaceful "
                       "and intimate.",
        "time": "8:30 PM, Wednesday",
        "characters_present": "Arjun, Isha",
        "atmosphere": "Romantic tension, nervous excitement, genuine connection",
        "visuals": {
            "Arjun": "Standing under the fairy lights, determined but vulnerable. Waiting for her.",
            "Isha": "Arriving for her usual evening writing routine, surprised to see him.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """(surprised) "Arjun? What are you doing here this late?" """},
            {"speaker": "ARJUN", "line": """(direct, nervous) "Waiting for you. I've made my decision." """},
            {"speaker": "ISHA", "line": """(hoping, scared to show it) "You have?" """},
            {"speaker": "ARJUN", "line": """(walking closer) "I'm choosing you. For the exhibition. I need you to understand why." """},
            {"speaker": "ARJUN", "line": """"Your work is real. You understand what 'Untold Stories' actually means. When I think about creating something that matters, I think about doing it with you." """},
            {"speaker": "ISHA", "line": """(soft) "What about Priya?" """},
            {"speaker": "ARJUN", "line": """"She'll be upset. But she's strong, and deep down she'll understand it's right for the project." """},
            {"speaker": "ISHA", "line": """(stepping closer) "And us — working together for months on something this intimate?" """},
            {"speaker": "ARJUN", "line": """(meeting her eyes) "That's what I'm most excited about." """},
            {"speaker": "NARRATOR", "line": "They're standing very close now. A moment of tension."},
            {"speaker": "ISHA", "line": """(softly) "Okay then. Let's create something untold, together." """},
            {"speaker": "NARRATOR", "line": "They almost kiss — but pull back. Not yet."},
        ],
        "choices": [
            {"text": "Tell Priya immediately.", "next": "SCENE_004C"},
            {"text": "Spend the night planning with Isha first.", "next": "SCENE_004D"},
        ],
    },

    "SCENE_003D": {
        "title": "A Day to Think",
        "background": "Arjun's small apartment, evening. Papers from both conversations "
                      "spread across his desk.",
        "time": "9:00 PM, Wednesday — the day Isha asked for",
        "characters_present": "Arjun (alone, then a phone call)",
        "atmosphere": "Restless, weighing two people against each other",
        "visuals": {
            "Arjun": "Pacing his room, phone in hand, unable to settle on what to say to Priya.",
        },
        "dialogue": [
            {"speaker": "NARRATOR", "line": "Arjun promised Isha he'd talk to Priya before deciding anything. He's been staring at her contact for ten minutes."},
            {"speaker": "ARJUN", "line": """(muttering to himself) "There's no version of this call that doesn't hurt someone." """},
            {"speaker": "NARRATOR", "line": "He finally calls. Priya picks up on the second ring, already half-guessing why."},
            {"speaker": "PRIYA", "line": """(on the phone) "You're calling this late. That's never a good sign." """},
            {"speaker": "ARJUN", "line": """"I spent the afternoon with Isha. Talking about the project." """},
            {"speaker": "PRIYA", "line": """(flat) "Of course you did." """},
            {"speaker": "ARJUN", "line": """"I haven't decided anything yet. I wanted to tell you myself before you heard it some other way." """},
            {"speaker": "PRIYA", "line": """(after a pause) "I appreciate that, actually. Most people wouldn't bother." """},
            {"speaker": "ARJUN", "line": """"Can we talk properly tomorrow? All three of us, or just us — whatever's fair." """},
            {"speaker": "PRIYA", "line": """"Fair would've been deciding before you spent the afternoon with her. But fine. Tomorrow." """},
        ],
        "choices": [
            {"text": "Ask all three to meet together tomorrow.", "next": "SCENE_002C"},
            {"text": "Meet Priya alone first to be honest about where your head's at.", "next": "SCENE_004C"},
        ],
    },

    # ============================================================
    # ACT 2 — CONSEQUENCES
    # ============================================================

    "SCENE_004A": {
        "title": "The Test Collaboration Begins",
        "background": "Isha's dorm room, converted into a small studio. Warm, cozy, "
                       "books and sketches on every surface.",
        "time": "9:00 AM, Thursday",
        "characters_present": "Isha, Priya, Arjun (observing)",
        "atmosphere": "Tense collaboration, creative friction, mutual respect building",
        "visuals": {
            "Isha": "At her desk, nervous but committed.",
            "Priya": "Reviewing contact sheets on her camera, evaluating everything critically.",
            "Arjun": "Sitting apart, watching, hoping this works.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """(reading aloud) "There's a moment before speaking truth when your heart is the loudest thing in the room." """},
            {"speaker": "PRIYA", "line": """(looking up) "Read that again. Slower." """},
            {"speaker": "NARRATOR", "line": "Isha repeats it. Priya closes her eyes, listening. Something shifts in her face."},
            {"speaker": "PRIYA", "line": """"I have photos from 'Silent Screams' that could work with this. The girl crying on the phone at midnight. The couple not touching." """},
            {"speaker": "ISHA", "line": """(excited) "Yes — those are exactly the stories I was trying to write." """},
            {"speaker": "PRIYA", "line": """(first real warmth) "We both just watch people, I guess." """},
            {"speaker": "ARJUN", "line": """(to himself) "This might actually work..." """},
            {"speaker": "PRIYA", "line": """"If we pair these, the narrative needs to be fragmented — not linear. Moments of truth. Can you write that?" """},
            {"speaker": "ISHA", "line": """"Exactly. Short pieces, each standing alone but part of a whole." """},
            {"speaker": "PRIYA", "line": """(practical) "We'd need twenty, twenty-five pieces. Are you willing to write that much?" """},
            {"speaker": "ISHA", "line": """(without hesitation) "I'll write a hundred if I have to." """},
            {"speaker": "PRIYA", "line": """(warmer) "Then maybe this could work." """},
            {"speaker": "ARJUN", "line": """(standing) "So we're all in? This is happening?" """},
        ],
        "choices": [
            {"text": "\"Yes. We move forward with the project.\"", "next": "SCENE_005C"},
            {"text": "Priya hesitates — push her to commit fully.", "next": "SCENE_005D"},
        ],
    },

    "SCENE_004B": {
        "title": "Priya's Ultimatum",
        "background": "An empty classroom after hours. Impersonal, fluorescent-lit, tense.",
        "time": "5:00 PM, Thursday",
        "characters_present": "Arjun, Priya",
        "atmosphere": "Confrontational, final, relationship-changing",
        "visuals": {
            "Priya": "Arms crossed, controlled anger, not backing down.",
            "Arjun": "Sitting, frustrated, conflicted.",
        },
        "dialogue": [
            {"speaker": "PRIYA", "line": """(firm) "No, Arjun. No test collaboration. That's asking me to compromise before we even start." """},
            {"speaker": "ARJUN", "line": """(standing) "I'm asking you to be open." """},
            {"speaker": "PRIYA", "line": """"This is a prestigious exhibition. I don't have time to 'discover things.' I know what works." """},
            {"speaker": "ARJUN", "line": """"What if working with Isha makes your vision even better?" """},
            {"speaker": "PRIYA", "line": """(bitter laugh) "You're infatuated with her. That's what this is." """},
            {"speaker": "ARJUN", "line": """(defensive) "That's not fair." """},
            {"speaker": "PRIYA", "line": """"Isn't it? You want to work with her because there's something there — not because it's the best choice." """},
            {"speaker": "ARJUN", "line": """(quiet, because there's truth in it) "That's not completely unfair." """},
            {"speaker": "PRIYA", "line": """(softening slightly) "I've known you since first year. You're terrible at separating emotions from decisions." """},
            {"speaker": "ARJUN", "line": """"If my emotions are telling me her story could make this better, maybe I should listen." """},
            {"speaker": "PRIYA", "line": """(reaching her limit) "Then you're choosing her. Over me. Over what we could create." """},
            {"speaker": "ARJUN", "line": """"It's not choosing her over you. It's—" """},
            {"speaker": "PRIYA", "line": """(cutting him off, calm) "It is. Own it. Don't soften it into something it isn't." """},
            {"speaker": "ARJUN", "line": """(pained) "I don't want to lose you." """},
            {"speaker": "PRIYA", "line": """(walking to the door) "Then make a choice that honors our friendship — not your feelings for someone else." """},
            {"speaker": "ARJUN", "line": """(calling after her) "What are you going to do?" """},
            {"speaker": "PRIYA", "line": """(not turning back) "Find another collaborator. Prove I didn't need this experiment." """},
        ],
        "choices": [
            {"text": "Go after Priya and try to repair the friendship.", "next": "SCENE_006B"},
            {"text": "Accept her decision and move forward with Isha.", "next": "SCENE_004D"},
        ],
    },

    "SCENE_004C": {
        "title": "The Conversation with Priya",
        "background": "A photography studio near campus — Priya's domain. Prints on "
                       "every wall, equipment everywhere.",
        "time": "10:00 AM, Friday",
        "characters_present": "Arjun, Priya",
        "atmosphere": "Tense, confrontational, heartbreak",
        "visuals": {
            "Priya": "In her element, surrounded by her work. Expression hardens as he enters.",
            "Arjun": "Entering with determination but visible anxiety.",
        },
        "dialogue": [
            {"speaker": "PRIYA", "line": """(cold) "Let me guess. You chose Isha." """},
            {"speaker": "ARJUN", "line": """(shocked) "How did you—" """},
            {"speaker": "PRIYA", "line": """"I know you. You started defending her in the coffee shop. You'd already chosen — I was waiting for you to admit it." """},
            {"speaker": "ARJUN", "line": """(defensive) "I was genuinely torn." """},
            {"speaker": "PRIYA", "line": """(turning back to her work) "No, you were confused. Torn means weighing two equal options. You were justifying, not weighing." """},
            {"speaker": "ARJUN", "line": """(frustrated) "Maybe. But my reasoning's still valid. Her work is—" """},
            {"speaker": "PRIYA", "line": """(real hurt now) "I don't want to hear why her work is better. I want to know why you didn't fight for us." """},
            {"speaker": "ARJUN", "line": """(softening) "Because I was scared." """},
            {"speaker": "PRIYA", "line": """(sarcastic) "Of what — failing?" """},
            {"speaker": "ARJUN", "line": """"Of failing WITH you. And losing you on top of it. With Isha, if it fails, it's just the project." """},
            {"speaker": "PRIYA", "line": """(sitting down heavily) "Is that what this is? Emotional safety?" """},
            {"speaker": "ARJUN", "line": """"Maybe. Partly." """},
            {"speaker": "PRIYA", "line": """(controlled pain) "I actually believed in us, Arjun. I thought we could create something amazing." """},
            {"speaker": "ARJUN", "line": """(voice breaking) "We still can. Other projects—" """},
            {"speaker": "PRIYA", "line": """(shaking her head) "Not like this one. This was the one." """},
            {"speaker": "PRIYA", "line": """(without looking at him) "I'll find someone else. I'll be fine." """},
            {"speaker": "ARJUN", "line": """"Priya, I didn't mean to hurt you." """},
            {"speaker": "PRIYA", "line": """(eyes wet) "I know. That somehow makes it worse." """},
        ],
        "choices": [
            {"text": "Try to repair the friendship right now.", "next": "SCENE_006C"},
            {"text": "Give her space and accept the damage.", "next": "SCENE_004D"},
        ],
    },

    "SCENE_004D": {
        "title": "Building the Vision with Isha",
        "background": "Arjun's apartment — comfortable creative chaos. Sketches and mood "
                       "boards on the floor, design software open, tea going cold.",
        "time": "2:00 PM, Friday",
        "characters_present": "Arjun, Isha",
        "atmosphere": "Hopeful, creative energy, growing intimacy",
        "visuals": {
            "Isha": "Seated on the floor, surrounded by notebook pages, more relaxed than before.",
            "Arjun": "Pacing, gesturing enthusiastically, more energized than he ever was with Priya.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """(pointing at the boards) "Each of your stories becomes a visual installation. Your words built into the design itself — not just captions." """},
            {"speaker": "ISHA", "line": """(getting up) "The words become part of the design? Not separate from it?" """},
            {"speaker": "ARJUN", "line": """"Exactly. Typography as visual language. Big means important. Small means whispered. Hidden means the viewer has to search." """},
            {"speaker": "ISHA", "line": """(looking at his sketches) "This is exactly what I was imagining and couldn't say out loud." """},
            {"speaker": "ARJUN", "line": """"You articulate it. I translate it." """},
            {"speaker": "ISHA", "line": """(softly) "Are you okay, about Priya?" """},
            {"speaker": "ARJUN", "line": """(honest) "No. But I think I made the right choice, and I need that to be worth the cost." """},
            {"speaker": "ISHA", "line": """(taking his hand) "It is. I promise." """},
            {"speaker": "ARJUN", "line": """"When did you become the person I want to create with?" """},
            {"speaker": "ISHA", "line": """(small sad smile) "I've always been that person. You just weren't ready to see it." """},
            {"speaker": "ARJUN", "line": """(leaning in) "I see it now." """},
            {"speaker": "NARRATOR", "line": "They kiss — a moment of genuine connection and commitment."},
        ],
        "choices": [
            {"text": "Begin intense creative collaboration right away.", "next": "SCENE_005C"},
            {"text": "Take a step back and set boundaries before diving in.", "next": "SCENE_005E"},
        ],
    },

    "SCENE_005A": {
        "title": "Success and Regret",
        "background": "A professional gallery space, exhibition opening night. Priya's "
                       "work — and her new collaborator's — lines the walls. Bold, "
                       "commercial, beautifully curated.",
        "time": "Exhibition opening night, three months later",
        "characters_present": "Arjun, Priya",
        "atmosphere": "Bittersweet — success mixed with loss",
        "visuals": {
            "Arjun": "Walking through slowly, admiration mixed with regret.",
            "Priya": "Talking to curators and buyers across the room — professional, successful, something missing in her eyes.",
        },
        "dialogue": [
            {"speaker": "NARRATOR", "line": "He stands a long time in front of the photo she once described — the girl crying on the phone. It's powerful. Moving."},
            {"speaker": "ARJUN", "line": """(thinking) "She was right about all of it. The impact. The boldness." """},
            {"speaker": "NARRATOR", "line": "He finds her. She sees him too."},
            {"speaker": "ARJUN", "line": """(genuine) "These are some of the best photographs you've ever made." """},
            {"speaker": "PRIYA", "line": """(professional smile, distant eyes) "Thank you. The collaboration worked out well." """},
            {"speaker": "ARJUN", "line": """"I owe you an apology. I was wrong not to trust your vision." """},
            {"speaker": "PRIYA", "line": """"You weren't wrong. You were scared. There's a difference." """},
            {"speaker": "ARJUN", "line": """(frustrated) "Is there? I didn't choose this. I chose something quieter. Safer." """},
            {"speaker": "PRIYA", "line": """(pain visible) "And how's that working out?" """},
            {"speaker": "ARJUN", "line": """"I'm second-guessing everything." """},
            {"speaker": "PRIYA", "line": """(softer) "You made your choice. Don't come to me for validation. I'm happy with how this turned out. That has to be enough." """},
            {"speaker": "ARJUN", "line": """"Are you, though? Really happy?" """},
            {"speaker": "PRIYA", "line": """(after a pause) "I'm successful. That's what I wanted." """},
            {"speaker": "ARJUN", "line": """"But you're not happy." """},
            {"speaker": "PRIYA", "line": """(looking away) "Happiness is secondary to achievement. I thought you understood that." """},
            {"speaker": "NARRATOR", "line": "She excuses herself and walks away, leaving him alone among her beautiful work."},
        ],
        "choices": [
            {"text": "Accept this outcome and learn from it.", "next": "END_A"},
            {"text": "Try to repair things with Priya before the night ends.", "next": "SCENE_006D"},
        ],
    },

    "SCENE_005B": {
        "title": "Following Isha",
        "background": "Campus at twilight — library steps, then the path, then the "
                       "rooftop garden entrance.",
        "time": "6:30 PM, Wednesday",
        "characters_present": "Arjun, Isha",
        "atmosphere": "Chasing, desperate, a small chance at redemption",
        "visuals": {
            "Arjun": "Increasingly determined, out of breath, calling after her.",
            "Isha": "Moving fast, slowing only when she realizes he's actually following.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """(catching up at the garden) "Isha, wait. Please." """},
            {"speaker": "ISHA", "line": """(not turning around) "What do you want from me?" """},
            {"speaker": "ARJUN", "line": """(breathing hard) "To be honest. With you. With myself." """},
            {"speaker": "ISHA", "line": """(turning, tears in her eyes) "I don't want your honesty. I want your choice. You already made it." """},
            {"speaker": "ARJUN", "line": """"I made it wrong. I knew it the moment I said it." """},
            {"speaker": "ISHA", "line": """(voice breaking) "Then why did you say it?" """},
            {"speaker": "ARJUN", "line": """"Because Priya scared me. Because I'm a coward who decides based on other people's feelings instead of my own." """},
            {"speaker": "ISHA", "line": """(sitting on a bench) "That's not honesty, Arjun. That's manipulation. Telling me it was wrong doesn't change anything." """},
            {"speaker": "ARJUN", "line": """(sitting beside her) "I should have chosen you from the beginning." """},
            {"speaker": "ISHA", "line": """(tears falling) "But you didn't." """},
            {"speaker": "ARJUN", "line": """(reaching for her hand) "Can I undo it?" """},
            {"speaker": "ISHA", "line": """(pulling back) "You can't undo what you already promised Priya. That's not how integrity works." """},
            {"speaker": "ARJUN", "line": """"So you just walk away? We don't even try?" """},
            {"speaker": "ISHA", "line": """(standing) "This is about you learning that choices have consequences. That people aren't backup plans." """},
            {"speaker": "ARJUN", "line": """"I never treated you like a backup plan." """},
            {"speaker": "ISHA", "line": """(finally angry) "You measured us against each other. That IS treating me like a backup plan." """},
            {"speaker": "ARJUN", "line": """(devastated) "Isha—" """},
            {"speaker": "ISHA", "line": """(walking away) "Go create your exhibition with Priya. I'll move on. We both will." """},
            {"speaker": "ARJUN", "line": """(calling after her) "I love you! That's what I'm trying to say!" """},
            {"speaker": "NARRATOR", "line": "She stops. Doesn't turn around. But stops."},
            {"speaker": "ISHA", "line": """(without turning, soft) "Then why didn't you choose me?" """},
            {"speaker": "NARRATOR", "line": "She keeps walking, leaving him with the answer he can't give."},
        ],
        "choices": [
            {"text": "Focus on the exhibition with Priya, but carry the regret.", "next": "SCENE_005A"},
            {"text": "Try to rebuild something with Isha while still working with Priya.", "next": "SCENE_006E"},
        ],
    },

    "SCENE_005C": {
        "title": "The Project Takes Shape",
        "background": "A shared studio space the three of them have rented. Large, open, "
                       "covered in prints, written pages, and design mockups.",
        "time": "Six weeks into the project, evening",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Productive, hopeful, genuine collaboration",
        "visuals": {
            "Arjun": "At his design station, dark circles from long hours but genuinely energized.",
            "Priya": "Going through contact sheets, seeing her own photos in new ways because of Isha's words.",
            "Isha": "Writing, more confident than she's ever been.",
        },
        "dialogue": [
            {"speaker": "PRIYA", "line": """(holding up a contact sheet) "This one — the empty chair. Isha, what would you write for this?" """},
            {"speaker": "ISHA", "line": """(thinking) "The chair that holds every conversation we never had." """},
            {"speaker": "PRIYA", "line": """(nodding) "That's exactly what I felt taking it but couldn't say." """},
            {"speaker": "ARJUN", "line": """(turning from his station) "Minimal typography on this one. Just the chair. Words only appear when you get close." """},
            {"speaker": "NARRATOR", "line": "They look at each other. It's working."},
            {"speaker": "ISHA", "line": """(softly) "I can't believe we were going to do this separately." """},
            {"speaker": "PRIYA", "line": """(meeting Arjun's eyes) "Some of us were." """},
            {"speaker": "ARJUN", "line": """(guilt returning) "I was stupid." """},
            {"speaker": "PRIYA", "line": """(approaching him, gracious) "You were scared. But you chose vulnerability over safety. That's growth, not stupidity." """},
            {"speaker": "ARJUN", "line": """"When did you get so wise about this?" """},
            {"speaker": "PRIYA", "line": """(slightly sad smile) "When I realized her stories made my photographs better." """},
            {"speaker": "ISHA", "line": """"Are we actually going to win this?" """},
            {"speaker": "ARJUN", "line": """(looking at the work) "I think we might." """},
            {"speaker": "PRIYA", "line": """(serious) "There's something else, though. What happens after?" """},
            {"speaker": "ISHA", "line": """(quietly) "Do we go back to being separate? Or is there something here that continues?" """},
            {"speaker": "ARJUN", "line": """"I don't want to lose this. Whatever this is." """},
        ],
        "choices": [
            {"text": "Commit to staying as a creative trio after the exhibition.", "next": "SCENE_006F"},
            {"text": "Acknowledge this might be a singular moment that will pass.", "next": "SCENE_006G"},
        ],
    },

    "SCENE_005D": {
        "title": "Convincing Priya",
        "background": "Same dorm-room studio as the test collaboration, a little later "
                       "that same morning.",
        "time": "10:30 AM, Thursday",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Persuasive, a little fragile, hopeful",
        "visuals": {
            "Priya": "Standing near the door, camera bag half-packed, clearly still weighing it.",
            "Isha": "Watching quietly, not pushing.",
            "Arjun": "Stepping in to close the gap.",
        },
        "dialogue": [
            {"speaker": "PRIYA", "line": """(hand on her bag) "It's good work. I'm not denying that. I just don't know if I trust a whole exhibition to a 'maybe.'" """},
            {"speaker": "ARJUN", "line": """"What would make it a 'yes' instead of a 'maybe'?" """},
            {"speaker": "PRIYA", "line": """(thinking) "Equal say. Not just my photos serving her words. My eye matters too, on what story we tell." """},
            {"speaker": "ISHA", "line": """(stepping forward) "That's fair. I don't want to write captions for your pictures any more than you want to shoot illustrations for my lines." """},
            {"speaker": "PRIYA", "line": """(surprised by the directness) "...Okay. That's the first thing either of you has said that actually reassures me." """},
            {"speaker": "ARJUN", "line": """"So — equal partners. All three of us, no one's work serving anyone else's." """},
            {"speaker": "PRIYA", "line": """(setting her bag down) "Fine. Let's actually try this properly." """},
        ],
        "choices": [
            {"text": "Move forward together into full production.", "next": "SCENE_005C"},
        ],
    },

    "SCENE_005E": {
        "title": "Setting Boundaries",
        "background": "Arjun's apartment, the same evening as Scene 004D, the energy "
                       "now calmer and more deliberate.",
        "time": "6:00 PM, Friday",
        "characters_present": "Arjun, Isha",
        "atmosphere": "Careful, mature, quietly hopeful",
        "visuals": {
            "Isha": "Sitting cross-legged, notebook closed for once, fully present in the conversation.",
            "Arjun": "Sitting across from her, listening rather than pitching ideas.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """"Before we go further — I need this to be clear between us. Work hours and us-hours can't blur together, or we'll ruin both." """},
            {"speaker": "ARJUN", "line": """(considering) "So when we're working, we're collaborators first?" """},
            {"speaker": "ISHA", "line": """"Exactly. Critique each other honestly. Don't soften feedback because we kissed an hour earlier." """},
            {"speaker": "ARJUN", "line": """"And outside of that?" """},
            {"speaker": "ISHA", "line": """(smiling) "Outside of that, we're just two people figuring out if this works." """},
            {"speaker": "ARJUN", "line": """(nodding) "I like that this is something you thought about before things got complicated." """},
            {"speaker": "ISHA", "line": """"I'd rather build something that lasts than rush something that burns out in a month." """},
        ],
        "choices": [
            {"text": "Begin the project together, boundaries in place.", "next": "SCENE_005C"},
        ],
    },

    # ============================================================
    # ACT 3 — REPAIR, COMMITMENT, OR LETTING GO
    # ============================================================

    "SCENE_006A": {
        "title": "The Bold Proposal",
        "background": "A quiet coffee shop. Arjun at a corner table with sketches "
                       "spread out, meeting Priya first and Isha later that evening.",
        "time": "Evening, Thursday",
        "characters_present": "Arjun, then Priya, then Isha (separately)",
        "atmosphere": "Nervous energy, ambition, possibility",
        "visuals": {
            "Arjun": "Determined but anxious, sketches blending both women's styles spread before him.",
        },
        "dialogue": [
            {"speaker": "PRIYA", "line": """(sitting down, curious) "What's all this? Did you decide?" """},
            {"speaker": "ARJUN", "line": """(pushing the sketches forward) "A different idea. What if it's not me choosing — what if the three of us collaborate?" """},
            {"speaker": "PRIYA", "line": """(skeptical) "We already discussed that. It doesn't work." """},
            {"speaker": "ARJUN", "line": """"Not the way we discussed it. Equal contributions — your photography as the visual anchor, Isha's writing as the emotional core, my design tying it together." """},
            {"speaker": "PRIYA", "line": """"That means you give up final say." """},
            {"speaker": "ARJUN", "line": """"I know. I'm okay with that." """},
            {"speaker": "PRIYA", "line": """(pacing, cautious hope) "Give me time to think. Don't ask me right now." """},
            {"speaker": "ARJUN", "line": """(deflated but accepting) "Okay." """},
            {"speaker": "NARRATOR", "line": "Later that evening, Isha arrives."},
            {"speaker": "ISHA", "line": """(sitting, nervous) "You wanted to talk?" """},
            {"speaker": "ARJUN", "line": """(showing the same sketches) "I want you in this project. Equal partner, with Priya and me." """},
            {"speaker": "ISHA", "line": """(surprised) "Even after you chose Priya?" """},
            {"speaker": "ARJUN", "line": """"Because after I chose her, I realized I was wrong. I think we could build something impossible without you." """},
            {"speaker": "ISHA", "line": """"What did Priya say?" """},
            {"speaker": "ARJUN", "line": """"She's thinking about it. This isn't certain. I just wanted to know if you'd even consider it." """},
            {"speaker": "ISHA", "line": """(carefully) "Only if Priya genuinely agrees — and this can't be your way of getting me into the project after choosing someone else. It has to be a real creative decision." """},
            {"speaker": "ARJUN", "line": """(firmly) "It is. I promise." """},
        ],
        "choices": [
            {"text": "Both Priya and Isha agree to collaborate equally.", "next": "SCENE_005C"},
            {"text": "One agrees, but the other refuses.", "next": "SCENE_006H"},
        ],
    },

    "SCENE_006B": {
        "title": "Repairing the Friendship",
        "background": "The photography studio, night. Priya packing up her equipment "
                       "after the confrontation.",
        "time": "6:00 PM, Thursday",
        "characters_present": "Arjun, Priya",
        "atmosphere": "Vulnerable, tentative reconciliation",
        "visuals": {
            "Priya": "Packing cases, back turned, not looking at him.",
            "Arjun": "Standing in the doorway, gathering his words.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """(carefully) "Priya, I'm sorry. I know that's not enough, but I need to say it." """},
            {"speaker": "PRIYA", "line": """(not turning) "You're not sorry about the choice. You're sorry about the consequences." """},
            {"speaker": "ARJUN", "line": """(frustrated) "That's not true." """},
            {"speaker": "PRIYA", "line": """(turning, angry) "Isn't it? If you were truly sorry about the choice, you wouldn't have made it." """},
            {"speaker": "ARJUN", "line": """(stepping closer) "I'm sorry I hurt you. Sorry I didn't have the courage to choose you and stand by it — or choose her and own it. I did both halfway." """},
            {"speaker": "PRIYA", "line": """(sitting heavily) "Why did you come back, Arjun?" """},
            {"speaker": "ARJUN", "line": """(sitting beside her) "Because you matter to me more than the exhibition. More than any project. I can't let us end like this." """},
            {"speaker": "PRIYA", "line": """(voice breaking) "I don't know how to be your friend right now." """},
            {"speaker": "ARJUN", "line": """(taking her hand) "Then we don't try to be friends right now. We just exist. And later, we figure it out." """},
            {"speaker": "PRIYA", "line": """"What if we never figure it out?" """},
            {"speaker": "ARJUN", "line": """(honest) "Then I'll know my fear cost me something irreplaceable. And I'll live with that." """},
            {"speaker": "PRIYA", "line": """(squeezing his hand) "Don't choose Isha for the wrong reasons." """},
            {"speaker": "ARJUN", "line": """(surprised) "What do you mean?" """},
            {"speaker": "PRIYA", "line": """"If you work with her, make sure it's because her work is genuinely what the project needs. Not because you're running from me or toward her." """},
            {"speaker": "ARJUN", "line": """(realizing) "You're giving me permission." """},
            {"speaker": "PRIYA", "line": """(tears falling, nodding) "I'm acknowledging you have to live your own life. Even if it's not the one I wanted for you." """},
            {"speaker": "NARRATOR", "line": "He pulls her into an embrace. The reconciliation is fragile but real."},
        ],
        "choices": [
            {"text": "Accept this and move forward with the project.", "next": "SCENE_004D"},
            {"text": "Let this reconciliation spark a different idea — go all in on a true three-way collaboration.", "next": "SCENE_005C"},
        ],
    },

    "SCENE_006C": {
        "title": "Difficult Apology",
        "background": "The same photography studio as Scene 004C, now later in the "
                       "evening. Professional, but the cold has thawed slightly.",
        "time": "Same day, later evening",
        "characters_present": "Arjun, Priya",
        "atmosphere": "Tender apology, pain, possibility of healing",
        "visuals": {
            "Priya": "At her desk, looking at her own work rather than at him.",
            "Arjun": "Sitting across from her, no longer trying to win an argument.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """"I don't have words that make this okay." """},
            {"speaker": "PRIYA", "line": """"Then don't try to make it okay. Just tell me the truth." """},
            {"speaker": "ARJUN", "line": """"I was afraid. Afraid of disappointing you, but also afraid of succeeding with you — because that meant staying strictly professional, and I didn't want that." """},
            {"speaker": "PRIYA", "line": """(understanding dawning) "You wanted to protect yourself from falling for me by working with someone else." """},
            {"speaker": "ARJUN", "line": """(not confirming or denying, but it's clear) "I made a choice out of fear. I'm paying for it." """},
            {"speaker": "PRIYA", "line": """(walking to her prints) "You'll have to prove it, Arjun. Not with words — with how you move forward with this project. With her." """},
            {"speaker": "ARJUN", "line": """"How do I prove it?" """},
            {"speaker": "PRIYA", "line": """(turning back) "By making something honest. Something that matters." """},
            {"speaker": "ARJUN", "line": """"And if I do?" """},
            {"speaker": "PRIYA", "line": """(softer) "Then maybe, eventually, I forgive you." """},
        ],
        "choices": [
            {"text": "Accept this and move forward.", "next": "SCENE_004D"},
            {"text": "Ask if there's anything that could speed the forgiveness.", "next": "SCENE_006I"},
        ],
    },

    "SCENE_006D": {
        "title": "Finding Redemption",
        "background": "The gallery, late at night after the opening. Nearly empty, "
                       "spotlights still on the artwork.",
        "time": "10:30 PM, exhibition opening night",
        "characters_present": "Arjun, Isha",
        "atmosphere": "Late-night intimacy, a healing attempt",
        "visuals": {
            "Arjun": "Standing alone in front of Priya's work, lost in thought.",
            "Isha": "Entering through the main doors, surprised to find him still here.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """(surprised) "Arjun? What are you doing here so late?" """},
            {"speaker": "ARJUN", "line": """(turning) "Needed to think. Look at everything with fresh eyes." """},
            {"speaker": "ISHA", "line": """(joining him) "And?" """},
            {"speaker": "ARJUN", "line": """(gesturing to Priya's wall, then their smaller corner) "I made a choice that was smart but emotionally hollow. Hers is magnificent. Ours was honest." """},
            {"speaker": "ISHA", "line": """"So what are you saying?" """},
            {"speaker": "ARJUN", "line": """(taking her hands) "I'm sorry. I should have had the courage to choose you from the start. I want to do better." """},
            {"speaker": "ISHA", "line": """(soft) "This exhibition is over. We can't redo it." """},
            {"speaker": "ARJUN", "line": """(intense) "But we can create the next one. And the ten after that." """},
            {"speaker": "ISHA", "line": """(hesitant) "Only if you're choosing because you want me in your life — not out of guilt." """},
            {"speaker": "ARJUN", "line": """(stepping back) "Then let me show you. Not tonight. Over time." """},
            {"speaker": "ISHA", "line": """(after a long moment) "Then let's start tomorrow. No more guilt. Just creation." """},
            {"speaker": "NARRATOR", "line": "They share a quiet kiss in the gallery, surrounded by art — some of it theirs."},
        ],
        "choices": [
            {"text": "Begin building a relationship and a creative partnership.", "next": "SCENE_007A"},
            {"text": "Agree to establish boundaries first.", "next": "SCENE_007B"},
        ],
    },

    "SCENE_006E": {
        "title": "Holding Both",
        "background": "A neutral coffee shop, late afternoon, before a planned group "
                       "discussion with Priya.",
        "time": "5:00 PM, Friday",
        "characters_present": "Arjun, Isha, then Priya",
        "atmosphere": "Anticipatory, careful hope",
        "visuals": {
            "Isha": "Across the table, steady, supportive.",
            "Arjun": "Nervous about what comes next.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """"You're going to tell Priya about us, aren't you?" """},
            {"speaker": "ARJUN", "line": """(conflicted) "Shouldn't I?" """},
            {"speaker": "ISHA", "line": """"Depends what you're telling her. We're two people who admired each other's work and recently discovered we might love each other. That's enough for now." """},
            {"speaker": "ARJUN", "line": """"And when I tell her I made the wrong choice and want to redo it?" """},
            {"speaker": "ISHA", "line": """(taking his hand) "You don't say that. You just say you've decided to collaborate with me. Everything else is our story, not hers." """},
            {"speaker": "NARRATOR", "line": "Priya enters, sees them hand in hand, and reads the situation instantly."},
            {"speaker": "PRIYA", "line": """(approaching, controlled) "So. This is happening." """},
            {"speaker": "ARJUN", "line": """(standing, defensive) "Priya—" """},
            {"speaker": "PRIYA", "line": """(holding up a hand) "I'm not mad. I'm just here. What did you want to discuss?" """},
        ],
        "choices": [
            {"text": "Propose the three-way collaboration.", "next": "SCENE_006F"},
            {"text": "Just ask permission to work with Isha.", "next": "SCENE_006J"},
        ],
    },

    "SCENE_006F": {
        "title": "The Trio Commits",
        "background": "The shared creative space, a month before the exhibition. The "
                       "work in progress covers every wall.",
        "time": "One month before the exhibition",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Triumphant, hopeful, committed",
        "visuals": {
            "Arjun": "Emotional, looking at what they've built.",
            "Priya": "Examining details critically but warmly.",
            "Isha": "Stepping back to take in the whole.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """"We actually did this. We created something beautiful." """},
            {"speaker": "PRIYA", "line": """"It's not just beautiful. It's honest. Every element serves the whole." """},
            {"speaker": "ARJUN", "line": """(emotional) "This is what I dreamed about when I imagined this project." """},
            {"speaker": "PRIYA", "line": """"I have something to say, and I need you both to really hear it." """},
            {"speaker": "PRIYA", "line": """"When Arjun chose Isha over me, I thought my heart broke. I think my pride broke. And that's actually been a gift." """},
            {"speaker": "ISHA", "line": """(surprised) "How?" """},
            {"speaker": "PRIYA", "line": """"It forced me to look at my work without ego. Bold without purpose is just noise. I found purpose here — I found you both." """},
            {"speaker": "PRIYA", "line": """"So here's my proposal. After this exhibition — let's keep doing this. Not a one-time thing. An actual creative partnership." """},
            {"speaker": "ARJUN", "line": """(excited, cautious) "Like a permanent thing?" """},
            {"speaker": "PRIYA", "line": """(firm) "A collective. We take on projects together, build something bigger than any of us alone." """},
            {"speaker": "ISHA", "line": """(to Arjun) "What do you think?" """},
            {"speaker": "ARJUN", "line": """"I think it's the best idea anyone's had." """},
            {"speaker": "NARRATOR", "line": "The three of them join hands, looking at their work, at each other, at the future."},
        ],
        "choices": [
            {"text": "Move to the exhibition opening, triumphant.", "next": "SCENE_007C"},
            {"text": "Begin planning the future beyond this project.", "next": "SCENE_007D"},
        ],
    },

    "SCENE_006G": {
        "title": "Acknowledging the Temporary",
        "background": "The same shared studio, days before the exhibition. The mood is "
                       "reflective, gentler than before.",
        "time": "Days before the exhibition",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Bittersweet, mature, accepting",
        "visuals": {
            "Isha": "Saying what everyone's been thinking.",
            "Priya": "Sitting down, pragmatic.",
            "Arjun": "Resisting the idea of an ending.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """"We're not going to keep doing this after the exhibition, are we?" """},
            {"speaker": "PRIYA", "line": """(sitting) "I don't think so. Not like this." """},
            {"speaker": "ARJUN", "line": """(defensive) "Why not? We work perfectly together." """},
            {"speaker": "PRIYA", "line": """(kind but firm) "Because this is what we needed at this moment — this exact intersection of timing, need, and chemistry." """},
            {"speaker": "ISHA", "line": """"If we forced it to continue, we'd ruin what we made here." """},
            {"speaker": "ARJUN", "line": """(struggling) "So we just end?" """},
            {"speaker": "PRIYA", "line": """(correcting) "We complete. There's a difference. There's honor in completion." """},
            {"speaker": "ISHA", "line": """(to Arjun) "We'll still care about each other. Still see each other's work. Just not try to create as a unit." """},
            {"speaker": "PRIYA", "line": """(extending hands) "Let's promise something. Whatever happens — this defined something in us that won't change." """},
            {"speaker": "NARRATOR", "line": "They join hands in the studio, looking at what they've created."},
            {"speaker": "ARJUN", "line": """(softly) "To Canvas & Conflict." """},
            {"speaker": "NARRATOR", "line": "\"To Canvas & Conflict,\" all three say together."},
        ],
        "choices": [
            {"text": "Move to the exhibition opening.", "next": "SCENE_007C"},
            {"text": "Jump forward to one year later.", "next": "SCENE_007E"},
        ],
    },

    "SCENE_006H": {
        "title": "When One Says No",
        "background": "Different corners of campus, separate conversations converging "
                       "into one outcome.",
        "time": "Friday evening",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Compromise, adaptation, a new direction",
        "visuals": {
            "Priya": "Declining gently but firmly.",
            "Isha": "Agreeing, but only on her own terms.",
        },
        "dialogue": [
            {"speaker": "PRIYA", "line": """"I appreciate what you're trying to do. But my answer's still no. I can't create my best work managing other people's feelings and ego. It's not a judgment on either of you — it's just how I work." """},
            {"speaker": "ISHA", "line": """"Yes — if you're sure this is what you want. But it has to be the best artistic choice, not you trying to fix things with Priya." """},
            {"speaker": "ARJUN", "line": """(at the crossroads) "So I work with Isha. And I lose Priya." """},
            {"speaker": "PRIYA", "line": """(softly) "You don't lose me. I'm just not part of this project." """},
            {"speaker": "ARJUN", "line": """"Will you hate me?" """},
            {"speaker": "PRIYA", "line": """(honest) "No. But I'll be sad. I'll need space." """},
            {"speaker": "ISHA", "line": """"This is real, by the way. Not everyone can be in the same project." """},
            {"speaker": "ARJUN", "line": """(accepting) "Then I choose this path. With Isha. I hope, eventually, Priya can see why it had to be this way." """},
            {"speaker": "PRIYA", "line": """(turning to leave) "Maybe I will. Right now, I need to go create my own thing." """},
        ],
        "choices": [
            {"text": "Focus on the project with Isha, let Priya go.", "next": "SCENE_004D"},
            {"text": "Immediately regret it and follow Priya.", "next": "SCENE_006B"},
        ],
    },

    "SCENE_006I": {
        "title": "Learning to Wait",
        "background": "A coffee shop, neutral ground. Weeks into separately working on "
                       "the project.",
        "time": "Two weeks before the exhibition",
        "characters_present": "Arjun, Priya",
        "atmosphere": "Mature, healing, acceptance",
        "visuals": {
            "Arjun": "Seeking closure.",
            "Priya": "Surprisingly at peace.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """"I need to know if you'll ever forgive me." """},
            {"speaker": "PRIYA", "line": """(looking at her coffee) "I already have." """},
            {"speaker": "ARJUN", "line": """(surprised) "When?" """},
            {"speaker": "PRIYA", "line": """(meeting his eyes) "When I saw what you made with Isha. It was real. Honest. Exactly what the project needed." """},
            {"speaker": "ARJUN", "line": """(frustrated) "Then why does it still feel broken between us?" """},
            {"speaker": "PRIYA", "line": """(leaning forward) "Because forgiveness isn't forgetting. It's accepting that something you wanted didn't happen, and being okay with it anyway." """},
            {"speaker": "ARJUN", "line": """"Are you okay with it?" """},
            {"speaker": "PRIYA", "line": """(considering) "Getting there. My project's going to be exceptional. I did that without you. Maybe that's what I needed too." """},
            {"speaker": "ARJUN", "line": """(relief and sadness) "Can we be friends again?" """},
            {"speaker": "PRIYA", "line": """(small smile) "We already are. Just not collaborators. That's okay." """},
            {"speaker": "PRIYA", "line": """(gathering her things) "Don't thank me yet. Let's see how you grow from this. That's when you'll know if you're really sorry." """},
        ],
        "choices": [
            {"text": "Accept this new normal.", "next": "SCENE_007A"},
            {"text": "Keep trying to repair things further.", "next": "SCENE_006J"},
        ],
    },

    "SCENE_006J": {
        "title": "Simple Request",
        "background": "A neutral coffee shop, Priya seated, Arjun asking plainly.",
        "time": "Friday evening",
        "characters_present": "Arjun, Priya (Isha waiting outside)",
        "atmosphere": "Simple, direct, no false drama",
        "visuals": {
            "Priya": "Considering his request with surprising calm.",
            "Arjun": "Asking for something more like a blessing than permission.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """"I want to work with Isha on this. Do I have your blessing?" """},
            {"speaker": "PRIYA", "line": """(amused) "Blessing? You're an adult, Arjun. You don't need my permission." """},
            {"speaker": "ARJUN", "line": """(insistent) "No — but I want your blessing. That's different." """},
            {"speaker": "PRIYA", "line": """"What would that look like to you?" """},
            {"speaker": "ARJUN", "line": """"That you're not angry. That you can look at what we make and appreciate it for what it is." """},
            {"speaker": "PRIYA", "line": """(standing) "I can do that. But promise me something. Don't hide behind her to avoid your fear of disappointing people. Do the work. Honestly." """},
            {"speaker": "ARJUN", "line": """(nodding) "I promise." """},
            {"speaker": "PRIYA", "line": """(extending her hand) "Then you have my blessing. Now go create something beautiful." """},
        ],
        "choices": [
            {"text": "Begin the project with Isha.", "next": "SCENE_004D"},
            {"text": "An unexpected moment with Isha before diving in.", "next": "SCENE_006K"},
        ],
    },

    "SCENE_006K": {
        "title": "Before the Project Begins",
        "background": "The coffee shop parking lot, dusk.",
        "time": "Evening, Friday",
        "characters_present": "Arjun, Isha",
        "atmosphere": "Peaceful transition, quiet hope",
        "visuals": {
            "Isha": "Waiting on a bench.",
            "Arjun": "Stepping into a new chapter, still catching his breath from the last one.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """(sitting beside her) "I have Priya's blessing." """},
            {"speaker": "ISHA", "line": """"How do you feel about that?" """},
            {"speaker": "ARJUN", "line": """"Relieved. Guilty. Grateful. Terrified." """},
            {"speaker": "ISHA", "line": """(soft) "Good. That means you understand what you're doing." """},
            {"speaker": "ARJUN", "line": """"We need to talk about what this means for us." """},
            {"speaker": "ISHA", "line": """"We do." """},
            {"speaker": "ARJUN", "line": """"I don't want complications to ruin our collaboration." """},
            {"speaker": "ISHA", "line": """(taking his hand) "Then let's be clear: two people who happen to love each other, choosing to create together. Not because of romance — alongside it." """},
            {"speaker": "ARJUN", "line": """"So the work comes first?" """},
            {"speaker": "ISHA", "line": """(firm) "The work always comes first. That's what artists do." """},
            {"speaker": "NARRATOR", "line": "They sit together as the sun sets, the weight of the choice settling comfortably between them."},
        ],
        "choices": [
            {"text": "Jump forward to the project's final stages.", "next": "SCENE_005C"},
            {"text": "Go straight to the exhibition opening night.", "next": "SCENE_007F"},
        ],
    },

    # ============================================================
    # EPILOGUES
    # ============================================================

    "END_A": {
        "title": "Moving Forward Alone",
        "background": "The gallery, much later that night. Most guests have left.",
        "time": "Late, exhibition opening night",
        "characters_present": "Arjun (alone)",
        "atmosphere": "Quiet acceptance",
        "visuals": {
            "Arjun": "Standing alone among Priya's work, no longer trying to fix what's done.",
        },
        "dialogue": [
            {"speaker": "ARJUN", "line": """(thinking) "I made a choice out of fear, and it cost me something I can't fully name." """},
            {"speaker": "NARRATOR", "line": "He doesn't chase an apology tonight. He lets the evening end as it is — a lesson, not a tragedy."},
            {"speaker": "ARJUN", "line": """(quietly, to no one) "Next time, I choose with my eyes open." """},
        ],
        "choices": [],
        "is_ending": True,
        "ending_label": "ENDING: The Cost of Safety",
    },

    "SCENE_007A": {
        "title": "One Year Later — Coffee Meeting",
        "background": "The same coffee shop where much of the story happened, now just "
                       "a comfortable meeting place.",
        "time": "One year after the exhibition",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Triumphant, appreciative, genuinely happy",
        "visuals": {
            "Priya": "Now teaching at the university, proud.",
            "Isha": "Recently published, crediting her collaborators freely.",
            "Arjun": "Carrying a portfolio of work that grew out of Canvas & Conflict.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """(laughing) "I can't believe you're teaching at the university now." """},
            {"speaker": "PRIYA", "line": """(proud) "I can't believe you got published. Do you know how many poets submit?" """},
            {"speaker": "ISHA", "line": """"I had good collaborators." """},
            {"speaker": "ARJUN", "line": """(shaking his head) "You did the work. We just facilitated it." """},
            {"speaker": "PRIYA", "line": """"Canvas & Conflict is being featured in a retrospective next year. They want all three of us on a panel." """},
            {"speaker": "ARJUN", "line": """(excited) "Are you serious?" """},
            {"speaker": "ISHA", "line": """(to Arjun, then Priya) "For something that important — yes." """},
            {"speaker": "ARJUN", "line": """(firmly) "Absolutely." """},
            {"speaker": "PRIYA", "line": """(raising her cup) "To Canvas & Conflict. The project that taught us all something about collaboration, choice, and growth." """},
            {"speaker": "NARRATOR", "line": "They clink cups — three people who became something greater than the sum of their parts."},
        ],
        "choices": [],
        "is_ending": True,
        "ending_label": "ENDING A: Rediscovered Friendship",
    },

    "SCENE_007B": {
        "title": "Three Months In — Establishing Rhythm",
        "background": "The shared studio, now organized with clear zones for each "
                       "person's work but visibly shared.",
        "time": "Three months after choosing to build something real",
        "characters_present": "Arjun, Isha",
        "atmosphere": "Realistic, mature, hopeful",
        "visuals": {
            "Isha": "Holding a notebook, setting ground rules with care, not coldness.",
            "Arjun": "Listening, learning the wisdom of structure.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """"We need working hours and personal hours. Non-negotiable." """},
            {"speaker": "ARJUN", "line": """(defensive) "Are you saying you don't want to spend time together?" """},
            {"speaker": "ISHA", "line": """(firm but kind) "I'm saying if we don't separate them, we'll destroy both. Bad creative days become relationship fights. Relationship problems become blamed on the work." """},
            {"speaker": "ARJUN", "line": """(seeing the wisdom) "So what do we do?" """},
            {"speaker": "ISHA", "line": """"Weekdays, nine to five — we're collaborators. Professional. Honest critique. After five, we're just two people figuring this out. Weekends — completely ours." """},
            {"speaker": "ARJUN", "line": """(standing, understanding) "This is wise. You're wise." """},
            {"speaker": "ISHA", "line": """(pulling him close) "We're wise together." """},
            {"speaker": "NARRATOR", "line": "Six months later, they submit Canvas & Conflict to the exhibition. It's accepted, and gets critical acclaim. Their relationship is strong precisely because the boundary held."},
        ],
        "choices": [],
        "is_ending": True,
        "ending_label": "ENDING B: Built on Boundaries",
    },

    "SCENE_007C": {
        "title": "Exhibition Opening — Canvas & Conflict",
        "background": "A premier art gallery, packed with critics, artists, collectors, "
                       "and friends. Canvas & Conflict in its full, finished glory.",
        "time": "Opening night of the exhibition",
        "characters_present": "Arjun, Priya, Isha, gallery visitors",
        "atmosphere": "Celebratory, triumphant, validating",
        "visuals": {
            "Arjun": "Glowing with quiet pride, talking to visitors.",
            "Priya": "Beaming, answering questions about the photography.",
            "Isha": "Emotional, watching strangers read her words on the walls.",
        },
        "dialogue": [
            {"speaker": "NARRATOR", "line": "A visitor remarks how seamless the collaboration feels — like one person's vision."},
            {"speaker": "ARJUN", "line": """"It's three people's visions. We just chose to trust each other completely." """},
            {"speaker": "PRIYA", "line": """"My photography had to serve the story, not the other way around." """},
            {"speaker": "ISHA", "line": """"And my words had to become visual, not just poetic." """},
            {"speaker": "NARRATOR", "line": "A critic asks about the title — about the conflicts behind the canvas."},
            {"speaker": "PRIYA", "line": """"We fought. We disagreed. We questioned each other's contributions." """},
            {"speaker": "ISHA", "line": """"And chose to see conflict as creative fuel, not relationship damage." """},
            {"speaker": "NARRATOR", "line": "Later, away from the crowd, the three of them stand in front of their work, silent, taking it in."},
            {"speaker": "ARJUN", "line": """(softly) "We did this." """},
            {"speaker": "PRIYA", "line": """(emotional) "We absolutely did this." """},
            {"speaker": "ISHA", "line": """"I know we said this might be temporary. I don't want it to be." """},
            {"speaker": "PRIYA", "line": """(firm) "Neither do I. Not if we can keep creating at this level." """},
            {"speaker": "ARJUN", "line": """"So we keep going?" """},
            {"speaker": "NARRATOR", "line": "\"We keep going,\" all three say together, and embrace in front of the work that brought them here."},
            {"speaker": "NARRATOR", "line": "Canvas & Conflict went on to win three national awards. The three of them formed an official collective and have created together for years since."},
        ],
        "choices": [],
        "is_ending": True,
        "ending_label": "ENDING C: True Collaboration",
    },

    "SCENE_007D": {
        "title": "The Collective Begins",
        "background": "A larger, upgraded studio — now clearly a permanent creative "
                       "headquarters, with mood boards for future projects on the walls.",
        "time": "Three months after the exhibition",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Ambitious, future-focused, exciting",
        "visuals": {
            "Priya": "Presenting a business plan, strategic and energized.",
            "Isha": "Thoughtful, protective of what makes their work special.",
            "Arjun": "Pragmatic, sketching out a manifesto.",
        },
        "dialogue": [
            {"speaker": "PRIYA", "line": """"If we form an official collective, we can take bigger commissions. Brands, documentaries, installations." """},
            {"speaker": "ISHA", "line": """"But we have to protect what makes us special — that we're choosing collaboration, not forced into it." """},
            {"speaker": "ARJUN", "line": """"We write a manifesto. Our principles. What we will and won't do." """},
            {"speaker": "PRIYA", "line": """(excited) "Exactly. I already have three proposals." """},
            {"speaker": "ISHA", "line": """(standing) "Then let's do this — not as a one-project thing. As an actual practice." """},
            {"speaker": "ARJUN", "line": """"A collective other artists want to join." """},
            {"speaker": "PRIYA", "line": """(extending both hands) "To Third Space. To always choosing growth." """},
            {"speaker": "NARRATOR", "line": "Two years later, they're lecturing at an art college about collaboration."},
            {"speaker": "ARJUN", "line": """(to students) "The hardest part isn't the creative work. It's the vulnerability of trusting someone else with your vision." """},
            {"speaker": "PRIYA", "line": """"But that vulnerability is where the real art happens." """},
            {"speaker": "ISHA", "line": """"Canvas and conflict. Both are necessary." """},
            {"speaker": "NARRATOR", "line": "Third Space Collective went on to create twelve major collaborative projects and mentor dozens of emerging artists."},
        ],
        "choices": [],
        "is_ending": True,
        "ending_label": "ENDING D: The Collective",
    },

    "SCENE_007E": {
        "title": "One Year Later — Separate Paths",
        "background": "Different cities, different studios — and finally, the original "
                       "rooftop garden where it all began.",
        "time": "One year after the exhibition",
        "characters_present": "Arjun, Priya, Isha",
        "atmosphere": "Bittersweet, proud, accepting of different paths",
        "visuals": {
            "Priya": "Running her own studio, photography book gaining international attention.",
            "Isha": "On a book tour, poetry collection award-winning, life moving in its own direction.",
            "Arjun": "Growing as a designer with new collaborators, life complicated but real.",
        },
        "dialogue": [
            {"speaker": "ISHA", "line": """(at the rooftop garden) "It's good to see you both." """},
            {"speaker": "PRIYA", "line": """(genuine) "You look happy." """},
            {"speaker": "ISHA", "line": """"I am. You?" """},
            {"speaker": "PRIYA", "line": """"Very. How about you, Arjun?" """},
            {"speaker": "ARJUN", "line": """"Happy and complicated. The real kind of happy." """},
            {"speaker": "ISHA", "line": """(thoughtfully) "Do you ever regret that we didn't stay a collective?" """},
            {"speaker": "PRIYA", "line": """(honest) "Sometimes. But Canvas & Conflict was a beginning, not the whole story." """},
            {"speaker": "ARJUN", "line": """"It taught us how to collaborate. It couldn't be the only collaboration forever." """},
            {"speaker": "ISHA", "line": """"We were still learning who we were individually. Now we know. Now we're whole people." """},
            {"speaker": "PRIYA", "line": """(standing, extending a hand) "Here's to Canvas & Conflict, for being exactly what we needed when we needed it." """},
            {"speaker": "ISHA", "line": """"And here's to whatever comes next." """},
            {"speaker": "ARJUN", "line": """"However we create it." """},
            {"speaker": "NARRATOR", "line": "They stand together, hands joined, watching the sunset — connected by this work, even as their futures diverge."},
        ],
        "choices": [],
        "is_ending": True,
        "ending_label": "ENDING E: Separate Paths",
    },

    "SCENE_007F": {
        "title": "Opening Night — Love Ascendant",
        "background": "The gallery, opening night. The exhibition is magnificent — but "
                       "the real story tonight is Arjun and Isha.",
        "time": "Exhibition opening night",
        "characters_present": "Arjun, Isha, Priya",
        "atmosphere": "Romantic, triumphant, love and art intertwined",
        "visuals": {
            "Arjun": "Nervous, holding something small in his pocket.",
            "Isha": "Radiant, standing in front of their installation about unspoken love.",
            "Priya": "Watching from a distance, genuinely happy for them.",
        },
        "dialogue": [
            {"speaker": "PRIYA", "line": """(pulling Arjun aside) "You love her." """},
            {"speaker": "ARJUN", "line": """(not denying it) "Yeah. I do." """},
            {"speaker": "PRIYA", "line": """(smiling genuinely) "Good. I'm glad it worked out that way." """},
            {"speaker": "NARRATOR", "line": "She hugs him and walks off to mingle, leaving him oddly blessed by his former rival."},
            {"speaker": "ARJUN", "line": """(finding Isha by their installation) "This one. This is about us, isn't it?" """},
            {"speaker": "ISHA", "line": """(turning to him) "This one was always about us. Even before we were us." """},
            {"speaker": "ARJUN", "line": """(taking her hand) "I need to ask you something important." """},
            {"speaker": "ISHA", "line": """(nervous) "Okay..." """},
            {"speaker": "ARJUN", "line": """(pulling out a small box) "In front of our work. In front of people who believe in us. Will you marry me?" """},
            {"speaker": "ISHA", "line": """(crying, laughing) "Yes. Yes, absolutely yes." """},
            {"speaker": "NARRATOR", "line": "Applause starts around them. The exhibition becomes the backdrop for the most important moment of the night."},
            {"speaker": "NARRATOR", "line": "Arjun and Isha were married six months later. Canvas & Conflict won the international competition. The three of them created together twice more before pursuing separate paths — forever bonded by the work that changed their lives."},
        ],
        "choices": [],
        "is_ending": True,
        "ending_label": "ENDING F: Love Ascendant",
    },
}
