"""
display.py
----------
All terminal rendering lives here. Keeping it separate from engine.py means
that when we add a graphical front-end later, only this module needs to be
swapped out (the engine and story data stay exactly the same).
"""

import os
import shutil
import sys
import time

try:
    from colorama import init as colorama_init, Fore, Style
    colorama_init(autoreset=True)
    COLOR_ENABLED = True
except ImportError:  # graceful fallback if colorama isn't installed
    COLOR_ENABLED = False

    class _NoColor:
        def __getattr__(self, _name):
            return ""
    Fore = _NoColor()
    Style = _NoColor()


# Map character names to colors so dialogue is easy to scan in the terminal
SPEAKER_COLORS = {
    "ARJUN": Fore.CYAN,
    "PRIYA": Fore.MAGENTA,
    "ISHA": Fore.GREEN,
    "NARRATOR": Fore.YELLOW,
    "SYSTEM": Fore.YELLOW,
}
DEFAULT_SPEAKER_COLOR = Fore.WHITE

RESET = Style.RESET_ALL if COLOR_ENABLED else ""
BOLD = Style.BRIGHT if COLOR_ENABLED else ""
DIM = Style.DIM if COLOR_ENABLED else ""


def _width() -> int:
    try:
        return min(shutil.get_terminal_size().columns, 100)
    except Exception:
        return 80


def clear_screen() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def hr(char: str = "=") -> None:
    print(DIM + char * _width() + RESET)


def print_title_banner(text: str) -> None:
    width = _width()
    print(BOLD + Fore.YELLOW + "=" * width)
    print(text.center(width))
    print("=" * width + RESET)


def print_scene_header(scene) -> None:
    """Prints the 'what's on screen' info block: title, background, time, etc."""
    hr()
    print(BOLD + Fore.YELLOW + f"[{scene.id}] {scene.title}" + RESET)
    hr("-")
    print(f"{BOLD}BACKGROUND:{RESET} {scene.background}")
    print(f"{BOLD}TIME:{RESET} {scene.time}")
    print(f"{BOLD}CHARACTERS PRESENT:{RESET} {scene.characters_present}")
    print(f"{BOLD}ATMOSPHERE:{RESET} {scene.atmosphere}")

    if scene.visuals:
        print()
        print(f"{BOLD}{Fore.YELLOW}-- Visual Details --{RESET}")
        for name, desc in scene.visuals.items():
            color = SPEAKER_COLORS.get(name.upper(), DEFAULT_SPEAKER_COLOR)
            print(f"  {color}{BOLD}{name}:{RESET} {desc}")
    hr()
    print()


def print_dialogue_line(speaker: str, line: str, typewriter: bool = False,
                         speed: float = 0.0) -> None:
    color = SPEAKER_COLORS.get(speaker.upper(), DEFAULT_SPEAKER_COLOR)
    label = f"{color}{BOLD}{speaker}:{RESET} "
    print(label, end="")
    if typewriter and speed > 0:
        for ch in line:
            sys.stdout.write(ch)
            sys.stdout.flush()
            time.sleep(speed)
        print()
    else:
        print(line)
    print()


def print_choices(choices) -> None:
    print(f"{BOLD}{Fore.YELLOW}What do you do?{RESET}")
    for i, choice in enumerate(choices, start=1):
        print(f"  {BOLD}{Fore.CYAN}[{i}]{RESET} {choice.text}")
    print(f"  {DIM}[save] save game   [quit] exit   [help] commands{RESET}")
    print()


def print_ending_banner(label: str) -> None:
    print()
    hr("*")
    msg = f"  THE END  —  {label}" if label else "  THE END  "
    print(BOLD + Fore.YELLOW + msg.center(_width()) + RESET)
    hr("*")
    print()


def print_help() -> None:
    print()
    print(f"{BOLD}Commands available at any choice prompt:{RESET}")
    print("  [number]  - pick that choice")
    print("  save      - save your current progress")
    print("  load      - load a previously saved game")
    print("  restart   - start the story over from the beginning")
    print("  quit      - exit the game")
    print("  help      - show this message again")
    print()


def prompt(text: str = "> ") -> str:
    try:
        return input(f"{BOLD}{Fore.CYAN}{text}{RESET}").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return "quit"
