"""
engine.py
---------
The game loop. Knows nothing about *what* the story says (that's
data/story_data.py) and nothing about *how* things are drawn beyond calling
into display.py. This separation is what will let us bolt on a graphical
front-end later without touching the story or the navigation logic.
"""

from typing import Dict, Optional

from . import display
from . import save_manager
from .models import Scene

START_SCENE_ID = "SCENE_001"


class StoryError(Exception):
    pass


class GameEngine:
    def __init__(self, raw_story_data: Dict[str, dict], start_scene: str = START_SCENE_ID):
        self.scenes: Dict[str, Scene] = {
            scene_id: Scene.from_dict(scene_id, data)
            for scene_id, data in raw_story_data.items()
        }
        self.start_scene_id = start_scene
        self.current_scene_id = start_scene
        self.history = [start_scene]
        self._validate_links()

    def _validate_links(self) -> None:
        """Sanity-check that every choice points to a scene that exists.
        Raises StoryError early (at startup) instead of crashing mid-playthrough.
        """
        missing = []
        for scene in self.scenes.values():
            for choice in scene.choices:
                if choice.next_scene not in self.scenes:
                    missing.append((scene.id, choice.next_scene))
        if missing:
            details = "\n".join(f"  {src} -> {dst} (missing)" for src, dst in missing)
            raise StoryError(f"Broken scene links found:\n{details}")

    def current_scene(self) -> Scene:
        return self.scenes[self.current_scene_id]

    def go_to(self, scene_id: str) -> None:
        if scene_id not in self.scenes:
            raise StoryError(f"Unknown scene id: {scene_id}")
        self.current_scene_id = scene_id
        self.history.append(scene_id)

    def restart(self) -> None:
        self.current_scene_id = self.start_scene_id
        self.history = [self.start_scene_id]

    # ---------------------------------------------------------------
    # Main loop
    # ---------------------------------------------------------------
    def play(self) -> None:
        while True:
            scene = self.current_scene()
            display.clear_screen()
            display.print_scene_header(scene)

            for d in scene.dialogue:
                display.print_dialogue_line(d.speaker, d.line)
                display.prompt("[enter to continue] ")

            if scene.is_ending:
                display.print_ending_banner(scene.ending_label or "")
                action = display.prompt("[1] Restart   [2] Quit  > ")
                if action in ("1", "restart"):
                    self.restart()
                    continue
                else:
                    print("\nThanks for playing Canvas & Conflict.\n")
                    return

            display.print_choices(scene.choices)
            self._handle_choice_prompt(scene)

    def _handle_choice_prompt(self, scene: Scene) -> None:
        while True:
            raw = display.prompt().lower()

            if raw in ("quit", "exit", "q"):
                print("\nThanks for playing Canvas & Conflict.\n")
                raise SystemExit(0)

            if raw == "help":
                display.print_help()
                continue

            if raw == "restart":
                self.restart()
                return

            if raw == "save":
                slot = display.prompt("Save slot name (default 'save1'): ") or "save1"
                path = save_manager.save_game(slot, self.current_scene_id, self.history)
                print(f"Saved to {path}\n")
                continue

            if raw == "load":
                slot = display.prompt("Save slot name to load (default 'save1'): ") or "save1"
                data = save_manager.load_game(slot)
                if data is None:
                    print("No save found with that name.\n")
                    continue
                self.current_scene_id = data["current_scene_id"]
                self.history = data.get("history", [self.current_scene_id])
                print("Loaded.\n")
                return

            if raw.isdigit():
                idx = int(raw) - 1
                if 0 <= idx < len(scene.choices):
                    self.go_to(scene.choices[idx].next_scene)
                    return
                print(f"Please enter a number between 1 and {len(scene.choices)}.\n")
                continue

            print("Didn't understand that. Type 'help' for commands.\n")
