"""
models.py
---------
Core data structures for the Canvas & Conflict visual novel engine.

These classes are intentionally simple (plain dataclasses) so that the same
story data can later be reused by a graphical front-end (Ren'Py, a web UI,
a Pygame UI, etc.) without rewriting the story content itself.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class Choice:
    """A single player choice, pointing to the next scene by id."""
    text: str
    next_scene: str


@dataclass
class DialogueLine:
    """One line of dialogue or stage direction.

    speaker is a character name (e.g. 'ARJUN') or a pseudo-speaker like
    'NARRATOR' for stage directions / scene description text that isn't
    attached to a specific character.
    """
    speaker: str
    line: str


@dataclass
class Scene:
    """A complete scene: everything that would be 'on screen' at once."""
    id: str
    title: str
    background: str
    time: str
    characters_present: str
    atmosphere: str
    visuals: Dict[str, str] = field(default_factory=dict)
    dialogue: List[DialogueLine] = field(default_factory=list)
    choices: List[Choice] = field(default_factory=list)
    is_ending: bool = False
    ending_label: Optional[str] = None  # e.g. "ENDING A: Rediscovered Friendship"

    @staticmethod
    def from_dict(scene_id: str, data: dict) -> "Scene":
        dialogue = [DialogueLine(speaker=d["speaker"], line=d["line"])
                    for d in data.get("dialogue", [])]
        choices = [Choice(text=c["text"], next_scene=c["next"])
                   for c in data.get("choices", [])]
        return Scene(
            id=scene_id,
            title=data.get("title", ""),
            background=data.get("background", ""),
            time=data.get("time", ""),
            characters_present=data.get("characters_present", ""),
            atmosphere=data.get("atmosphere", ""),
            visuals=data.get("visuals", {}),
            dialogue=dialogue,
            choices=choices,
            is_ending=data.get("is_ending", False),
            ending_label=data.get("ending_label"),
        )
