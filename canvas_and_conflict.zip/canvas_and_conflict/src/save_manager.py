"""
save_manager.py
----------------
Handles writing and reading save files. Saves are plain JSON so they're easy
to inspect, edit, or migrate later.
"""

import json
import os
from datetime import datetime
from typing import Optional

SAVE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "saves")


def _ensure_save_dir() -> None:
    os.makedirs(SAVE_DIR, exist_ok=True)


def save_path(slot: str) -> str:
    safe_slot = "".join(c for c in slot if c.isalnum() or c in ("-", "_")) or "save"
    return os.path.join(SAVE_DIR, f"{safe_slot}.json")


def save_game(slot: str, current_scene_id: str, history: list) -> str:
    """Writes a save file. Returns the path written to."""
    _ensure_save_dir()
    data = {
        "current_scene_id": current_scene_id,
        "history": history,
        "saved_at": datetime.now().isoformat(timespec="seconds"),
    }
    path = save_path(slot)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return path


def load_game(slot: str) -> Optional[dict]:
    """Reads a save file. Returns None if it doesn't exist or is invalid."""
    path = save_path(slot)
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def list_saves() -> list:
    """Returns a list of (slot_name, saved_at) tuples for all save files."""
    _ensure_save_dir()
    results = []
    for filename in sorted(os.listdir(SAVE_DIR)):
        if filename.endswith(".json"):
            slot = filename[:-5]
            data = load_game(slot)
            saved_at = data.get("saved_at", "unknown") if data else "unknown"
            results.append((slot, saved_at))
    return results
