"""
test_engine.py
--------------
Lightweight sanity checks. Run with:
    python -m tests.test_engine
(no pytest dependency required)
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.engine import GameEngine, START_SCENE_ID
from data.story_data import STORY


def test_all_links_resolve():
    """GameEngine raises at construction time if any choice points nowhere."""
    engine = GameEngine(STORY)  # would raise StoryError if broken
    assert engine.current_scene_id == START_SCENE_ID
    print("PASS: all scene links resolve to real scenes")


def test_every_scene_reachable_from_start():
    engine = GameEngine(STORY)
    visited = set()
    stack = [START_SCENE_ID]
    while stack:
        scene_id = stack.pop()
        if scene_id in visited:
            continue
        visited.add(scene_id)
        scene = engine.scenes[scene_id]
        for choice in scene.choices:
            stack.append(choice.next_scene)

    unreachable = set(engine.scenes.keys()) - visited
    assert not unreachable, f"Unreachable scenes: {unreachable}"
    print(f"PASS: all {len(visited)} scenes reachable from {START_SCENE_ID}")


def test_every_path_eventually_ends():
    """Walks every branch and confirms it terminates in an is_ending scene
    within a reasonable number of hops (catches infinite loops)."""
    engine = GameEngine(STORY)
    MAX_HOPS = 30

    def walk(scene_id, depth, path):
        if depth > MAX_HOPS:
            raise AssertionError(f"Path too long (possible loop): {path}")
        scene = engine.scenes[scene_id]
        if scene.is_ending:
            return
        if not scene.choices:
            raise AssertionError(f"Non-ending scene with no choices: {scene_id}")
        for choice in scene.choices:
            walk(choice.next_scene, depth + 1, path + [choice.next_scene])

    walk(START_SCENE_ID, 0, [START_SCENE_ID])
    print("PASS: every branch terminates in an ending scene")


def test_ending_count():
    engine = GameEngine(STORY)
    endings = [s for s in engine.scenes.values() if s.is_ending]
    assert len(endings) >= 1
    print(f"PASS: found {len(endings)} ending scenes")
    for e in endings:
        print(f"   - {e.id}: {e.ending_label}")


if __name__ == "__main__":
    test_all_links_resolve()
    test_every_scene_reachable_from_start()
    test_every_path_eventually_ends()
    test_ending_count()
    print("\nAll tests passed.")
